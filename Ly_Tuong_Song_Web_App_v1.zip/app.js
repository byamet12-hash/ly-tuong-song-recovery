const KEY="ly_tuong_song_v1";
const defaultState={
  goals:[
    {id:1,name:"Xây dựng Lý Tưởng Sống",progress:35},
    {id:2,name:"Phát triển Tư duy Gốc",progress:20}
  ],
  tasks:[
    {id:1,title:"Hoàn thiện ý tưởng Web App v1",goalId:1,done:false},
    {id:2,title:"Học một khái niệm công nghệ mới",goalId:2,done:false},
    {id:3,title:"Viết ra 1 việc quan trọng nhất hôm nay",goalId:null,done:true}
  ]
};
let state=load();
let modalMode="task";

const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];

function load(){
  try{return JSON.parse(localStorage.getItem(KEY))||structuredClone(defaultState)}
  catch{return structuredClone(defaultState)}
}
function save(){localStorage.setItem(KEY,JSON.stringify(state));render()}
function todayText(){return new Intl.DateTimeFormat("vi-VN",{weekday:"long",day:"2-digit",month:"2-digit",year:"numeric"}).format(new Date())}
function esc(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function goalName(id){return state.goals.find(g=>g.id===id)?.name||"Không gắn mục tiêu"}

function render(){
  $("#dateLabel").textContent=todayText();
  $("#statGoals").textContent=state.goals.length;
  const done=state.tasks.filter(t=>t.done).length;
  $("#statDone").textContent=`${done}/${state.tasks.length}`;
  const todayPct=state.tasks.length?Math.round(done/state.tasks.length*100):0;
  $("#statToday").textContent=todayPct+"%";
  const avg=state.goals.length?Math.round(state.goals.reduce((a,g)=>a+g.progress,0)/state.goals.length):0;
  $("#statProgress").textContent=avg+"%";
  renderGoals(); renderTasks(); renderProgress();
}

function goalHTML(g){
 return `<article class="goal-card">
   <span class="section-kicker">MỤC TIÊU</span><h3>${esc(g.name)}</h3><p>Tiến độ được cập nhật thủ công trong v1.</p>
   <div class="goal-meta"><span>Tiến độ</span><b>${g.progress}%</b></div>
   <div class="progress-track"><div class="progress-fill" style="width:${g.progress}%"></div></div>
   <div class="goal-actions">
     <button class="mini-btn" onclick="changeGoal(${g.id},-5)">−5%</button>
     <button class="mini-btn" onclick="changeGoal(${g.id},5)">＋5%</button>
     <button class="mini-btn danger" onclick="deleteGoal(${g.id})">Xóa</button>
   </div>
 </article>`
}
function renderGoals(){
 $("#goalsList").innerHTML=state.goals.length?state.goals.map(goalHTML).join(""):`<div class="panel"><b>Chưa có mục tiêu.</b><p>Hãy tạo mục tiêu đầu tiên.</p></div>`;
 $("#focusGoals").innerHTML=state.goals.slice(0,3).map(g=>`<div class="task-row"><div class="task-check">🎯</div><div><div class="task-title">${esc(g.name)}</div><div class="task-sub">${g.progress}% tiến độ</div></div><div class="task-spacer"><b>${g.progress}%</b></div></div>`).join("")||`<div class="list-empty">Chưa có mục tiêu.</div>`;
 $("#taskGoal").innerHTML=`<option value="">Không gắn mục tiêu</option>`+state.goals.map(g=>`<option value="${g.id}">${esc(g.name)}</option>`).join("");
}
function taskHTML(t){
 return `<div class="task-row ${t.done?"done":""}" data-id="${t.id}">
   <button class="task-check" onclick="toggleTask(${t.id})">${t.done?"✓":""}</button>
   <div><div class="task-title">${esc(t.title)}</div><div class="task-sub">${esc(goalName(t.goalId))}</div></div>
   <div class="task-spacer"><button class="mini-btn danger" onclick="deleteTask(${t.id})">Xóa</button></div>
 </div>`
}
function renderTasks(){
 const html=state.tasks.map(taskHTML).join("")||`<div class="list-empty">Chưa có việc. Hãy thêm một việc nhỏ.</div>`;
 $("#todayTasks").innerHTML=html;
 $("#planTasks").innerHTML=html;
 $("#focusTasks").innerHTML=state.tasks.slice(0,4).map(taskHTML).join("")||`<div class="list-empty">Hôm nay chưa có việc.</div>`;
 const done=state.tasks.filter(t=>t.done).length,p=state.tasks.length?Math.round(done/state.tasks.length*100):0;
 $("#todayPercent").textContent=p+"%";$("#todayBar").style.width=p+"%";
}
function renderProgress(){
 const avg=state.goals.length?Math.round(state.goals.reduce((a,g)=>a+g.progress,0)/state.goals.length):0;
 $("#ringText").textContent=avg+"%";
 $("#mainRing").style.background=`conic-gradient(#2563eb 0deg,#7c3aed ${avg*3.6}deg,#e8edf5 ${avg*3.6}deg)`;
 $("#progressMessage").textContent=avg===0?"Hãy bắt đầu bằng một mục tiêu và một việc nhỏ.":avg<40?"Bạn đã bắt đầu. Giữ nhịp bằng những bước nhỏ.":avg<80?"Đang tiến tốt. Tiếp tục tập trung vào việc quan trọng nhất.":"Tiến độ rất tốt. Hãy xem lại và đặt cột mốc tiếp theo.";
 $("#progressGoals").innerHTML=state.goals.map(goalHTML).join("");
}
function changeGoal(id,d){const g=state.goals.find(x=>x.id===id);if(g)g.progress=Math.max(0,Math.min(100,g.progress+d));save()}
function deleteGoal(id){if(confirm("Xóa mục tiêu này?")){state.goals=state.goals.filter(g=>g.id!==id);state.tasks.forEach(t=>{if(t.goalId===id)t.goalId=null});save()}}
function toggleTask(id){const t=state.tasks.find(x=>x.id===id);if(t)t.done=!t.done;save()}
function deleteTask(id){state.tasks=state.tasks.filter(t=>t.id!==id);save()}

function openModal(mode){
 modalMode=mode; $("#modal").classList.remove("hidden");
 $("#modalTitle").textContent=mode==="goal"?"Tạo mục tiêu":"Thêm việc";
 $("#goalField").classList.toggle("hidden",mode!=="goal");
 $("#taskField").classList.toggle("hidden",mode!=="task");
 $("#taskGoalField").classList.toggle("hidden",mode!=="task");
 $("#goalName").value="";$("#taskName").value="";
 setTimeout(()=>mode==="goal"?$("#goalName").focus():$("#taskName").focus(),50)
}
function closeModal(){$("#modal").classList.add("hidden")}

function showPage(page){
 $$(".page").forEach(p=>p.classList.toggle("active",p.id==="page-"+page));
 $$(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 const title=$(`[data-page="${page}"] span`)?.textContent||"Tổng quan";$("#pageTitle").textContent=title;
 $(".sidebar").classList.remove("open");window.scrollTo({top:0,behavior:"smooth"});
}

$$(".nav-item").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.page)));
$$("[data-page-link]").forEach(b=>b.addEventListener("click",()=>showPage(b.dataset.pageLink)));
$("#menuBtn").onclick=()=>$(".sidebar").classList.toggle("open");
$("#quickAdd").onclick=()=>openModal("task");
$("#todayAddBtn").onclick=()=>openModal("task");
$("#planAddBtn").onclick=()=>openModal("task");
$("#addGoalBtn").onclick=()=>openModal("goal");
$("#modalClose").onclick=closeModal;
$("#modal").addEventListener("click",e=>{if(e.target.id==="modal")closeModal()});
$("#modalForm").onsubmit=e=>{
 e.preventDefault();
 if(modalMode==="goal"){
   const name=$("#goalName").value.trim();if(!name)return;
   state.goals.push({id:Date.now(),name,progress:0});
 }else{
   const title=$("#taskName").value.trim();if(!title)return;
   state.tasks.unshift({id:Date.now(),title,goalId:$("#taskGoal").value?Number($("#taskGoal").value):null,done:false});
 }
 save();closeModal();
}
$("#resetBtn").onclick=()=>{if(confirm("Đặt lại toàn bộ dữ liệu mẫu?")){state=structuredClone(defaultState);save();showPage("home")}}

function assistantReply(text){
 const q=text.toLowerCase();
 if(q.includes("bao nhiêu")&&q.includes("mục tiêu"))return `Bạn đang có <b>${state.goals.length} mục tiêu</b>.`;
 if(q.includes("hôm nay")||q.includes("tiếp theo")){
   const next=state.tasks.find(t=>!t.done);
   return next?`Việc nên làm tiếp theo là: <b>${esc(next.title)}</b>.`:"Bạn đã hoàn thành toàn bộ việc hiện có. Hãy thêm một hành động mới.";
 }
 return `Tôi đang ở chế độ <b>v1 mô phỏng</b>. Tôi có thể giúp bạn xem mục tiêu, việc hôm nay và gợi ý việc tiếp theo. AI thật sẽ được kết nối ở phiên bản sau.`;
}
function sendChat(text){
 text=text.trim();if(!text)return;
 $("#chat").insertAdjacentHTML("beforeend",`<div class="bubble user">${esc(text)}</div>`);
 setTimeout(()=>{$("#chat").insertAdjacentHTML("beforeend",`<div class="bubble ai">${assistantReply(text)}</div>`);$("#chat").scrollTop=$("#chat").scrollHeight},180);
 $("#chatInput").value="";
}
$("#chatSend").onclick=()=>sendChat($("#chatInput").value);
$("#chatInput").addEventListener("keydown",e=>{if(e.key==="Enter")sendChat(e.target.value)});
$$(".suggestions button").forEach(b=>b.onclick=()=>sendChat(b.textContent));

render();
