# Lý Tưởng Sống — Web App v1

## Chạy trên tablet
1. Giải nén file ZIP.
2. Mở `index.html` bằng trình duyệt.
3. App chạy offline, không cần tài khoản hay API key.

## Có gì trong v1
- Tổng quan
- Mục tiêu + tiến độ
- Kế hoạch Năm → Tháng → Tuần → Ngày (khung giao diện)
- Việc hôm nay
- Tiến độ
- Tư duy gốc
- AI Trợ lý mô phỏng
- Lưu dữ liệu bằng Local Storage

## Cấu trúc
- index.html — giao diện
- style.css — thiết kế
- app.js — logic và dữ liệu

Bản sau có thể nối Firebase/Backend, đăng nhập, đồng bộ nhiều thiết bị và AI Agent thật.
